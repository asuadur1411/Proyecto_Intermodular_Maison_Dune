<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\maison\maison_dune_api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>