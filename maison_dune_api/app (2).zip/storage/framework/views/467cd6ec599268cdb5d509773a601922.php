<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\laragon\www\maison\maison_dune_api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>