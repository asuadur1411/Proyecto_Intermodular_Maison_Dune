<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Reservation extends Model
{
    protected $table = 'reservations';

    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'phone',
        'date',
        'time',
        'guests',
        'section',
        'notes',
    ];
}