<?php
/* Template Name: User Profile */
get_header();

// Obtenemos los datos nativos del usuario en WordPress
$current_user = wp_get_current_user();
$avatar_url = get_avatar_url($current_user->ID, ['size' => 150]);
$user_name = $current_user->display_name ?: $current_user->user_login;
?>

<section class="profile-section">
    <div class="profile-container">

        <div class="profile-header">
            <div class="profile-avatar">
                <img src="<?php echo esc_url($avatar_url); ?>" alt="Avatar de <?php echo esc_attr($user_name); ?>">
            </div>
            <div class="profile-greeting">
                <span class="greeting-sub">Bienvenido de nuevo</span>
                <h1 class="greeting-name">
                    <?php echo esc_html($user_name); ?>
                </h1>
            </div>
        </div>

        <div class="profile-reservations">
            <h2>Mis Reservas</h2>

            <div class="reservations-grid">
                <div class="reservation-board">
                    <h3>Habitaciones</h3>
                    <div class="board-content empty">
                        <p>Actualmente no posee ninguna reserva, haga la suya aquí.</p>
                        <a href="<?php echo esc_url(home_url('/rooms')); ?>" class="btn-reservar">Reservar</a>
                    </div>
                </div>

                <div class="reservation-board">
                    <h3>Restaurante Ziryab</h3>
                    <div class="board-content empty">
                        <p>Actualmente no posee ninguna reserva, haga la suya aquí.</p>
                        <a href="<?php echo esc_url(home_url('/table')); ?>" class="btn-reservar">Reservar</a>
                    </div>
                </div>

                <div class="reservation-board">
                    <h3>Eventos</h3>
                    <div class="board-content empty">
                        <p>Actualmente no posee ninguna reserva, haga la suya aquí.</p>
                        <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn-reservar">Reservar</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="profile-actions">
            <a href="<?php echo wp_logout_url(home_url('/login')); ?>" class="btn-logout">Cerrar Sesión</a>
        </div>

    </div>
</section>

<?php get_footer(); ?>